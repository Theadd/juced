/* =========================================================================================

   This is an auto-generated file: Any edits you make may be overwritten!

*/

namespace BinaryData
{
    extern const char*   knobstrip_png;
    const int            knobstrip_pngSize = 160459;

    // If you provide the name of one of the binary resource variables above, this function will
    // return the corresponding data and its size (or a null pointer if the name isn't found).
    const char* getNamedResource (const char* resourceNameUTF8, int& dataSizeInBytes) throw();
}
